package com.yash.assignment.service;

public interface UserService {
public boolean checkUser(String user,String password);
}
