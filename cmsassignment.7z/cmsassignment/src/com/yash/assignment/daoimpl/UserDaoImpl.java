package com.yash.assignment.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.assignment.dao.UserDao;
import com.yash.assignment.domain.User;
import com.yash.assignment.util.DBUtil;

public class UserDaoImpl implements UserDao{
	DBUtil dbutil=null;
	public UserDaoImpl() {
		dbutil=new DBUtil();
}
	@Override
	public boolean checkUserDao(User user) {
	Connection con=dbutil.getConnection();
	String str="Select loginid,password from logindetails where loginid=? and password=?";
	try {
		PreparedStatement pstmt=con.prepareStatement(str);
		pstmt.setString(1,user.getUserid());
		pstmt.setString(2,user.getPassword());
		java.sql.ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			return true;
		}
	
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
		return false;
	}

}
