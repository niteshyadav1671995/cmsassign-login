package com.yash.assignment.serviceimpl;

import com.yash.assignment.dao.UserDao;
import com.yash.assignment.daoimpl.UserDaoImpl;
import com.yash.assignment.domain.User;
import com.yash.assignment.service.UserService;

public class UserServiceImpl implements UserService{
	UserDao userDao=null;
public UserServiceImpl() {
userDao=new UserDaoImpl();
}
	@Override
	public boolean checkUser(String user, String password) {
	User checkuser=new User(user,password);
	return userDao.checkUserDao(checkuser);
	}

}
