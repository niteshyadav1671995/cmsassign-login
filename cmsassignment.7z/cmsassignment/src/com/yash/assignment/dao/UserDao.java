package com.yash.assignment.dao;

import com.yash.assignment.domain.User;

public interface UserDao {
public boolean checkUserDao(User checkuser);
}
