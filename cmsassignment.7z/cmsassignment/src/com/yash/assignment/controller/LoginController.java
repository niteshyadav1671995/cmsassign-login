package com.yash.assignment.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.assignment.service.UserService;
import com.yash.assignment.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserService userService=null;
	public void init() throws ServletException {
	userService=new UserServiceImpl();
		super.init();
}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String id=request.getParameter("loginid");
	String pass=request.getParameter("password");
	PrintWriter out=response.getWriter();
	out.println("login id : "+id+" Password :"+pass);
	if(userService.checkUser(id,pass)) {
		out.println("Login Success");		
	}
	else {
		out.println("Login Failed");
	}
}
}